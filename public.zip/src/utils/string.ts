const getStringForApi = (data: string) =>
  data.toLowerCase().replaceAll(" ", "_");

export { getStringForApi };
